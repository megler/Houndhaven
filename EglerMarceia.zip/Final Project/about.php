<!DOCTYPE html>
<html lang="en">
<head>
	<?php include("inc/meta.php"); ?>
	<title>Houndhaven - About Us</title>
</head>
<body>
	<header>
     	<?php include("inc/nav.php"); ?>  
    </header>
<h1>I'm going to be the About Us Page!</h1>

	<footer class="footer">
		<?php include("inc/footer.php"); ?>
	</footer>
    	<?php include("inc/foot-scripts.php"); ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php include("inc/meta.php"); ?>
	<title>Houndhaven - Wish List</title>
</head>
<body>
	<header>
     	<?php include("inc/nav.php"); ?>  
    </header>
<h1>I'm going to have the Wish List!</h1>

	<footer class="footer">
		<?php include("inc/footer.php"); ?>
	</footer>
    	<?php include("inc/foot-scripts.php"); ?>
</body>
</html>
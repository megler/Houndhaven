<!DOCTYPE html>
<html lang="en">
<head>
	<?php include("inc/meta.php"); ?>
	<title>Houndhaven - Contact Us</title>
</head>
<body>
	<header>
     	<?php include("inc/nav.php"); ?>  
    </header>
<h1>I'm going to be the Contact Page</h1>

	<footer class="footer">
		<?php include("inc/footer.php"); ?>
	</footer>
    	<?php include("inc/foot-scripts.php"); ?>
</body>
</html>
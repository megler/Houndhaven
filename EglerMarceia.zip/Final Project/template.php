<!DOCTYPE html>
<html lang="en">
<head>
	<?php include("inc/meta.php"); ?>
	<title>TEMPLATE</title>
</head>
<body>
	<header>
     	<?php include("inc/nav.php"); ?>  
    </header>
<h1>I'm a template!</h1>

	<footer class="footer">
		<?php include("inc/footer.php"); ?>
	</footer>
    	<?php include("inc/foot-scripts.php"); ?>
</body>
</html>